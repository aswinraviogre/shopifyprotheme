import { Component } from '@theme/component';
import {
  supportsViewTransitions,
  startViewTransition,
  onAnimationEnd,
  prefersReducedMotion,
  debounce,
  preloadImage,
  isLowPowerDevice,
} from '@theme/utilities';
import { scrollIntoView } from '@theme/scrolling';
import { ZoomMediaSelectedEvent } from '@theme/events';
import { DialogCloseEvent } from '@theme/dialog';
/**
 * A custom element that renders a zoom dialog.
 *
 * @typedef {object} Refs
 * @property {HTMLDialogElement} dialog - The dialog element.
 * @property {HTMLElement[]} media - The media elements.
 * @property {HTMLElement} thumbnails - The thumbnails elements.
 *
 * @extends Component<Refs>
 */
export class ZoomDialog extends Component {
  requiredRefs = ['dialog', 'media', 'thumbnails'];

  #highResImagesLoaded = /** @type {Set<string>} */ (new Set());

  connectedCallback() {
    super.connectedCallback();
    this.refs.dialog.addEventListener('scroll', this.handleScroll);
    const galleryList = this.querySelector('.dialog-zoomed-gallery');
    if (galleryList) {
      galleryList.addEventListener('scroll', this.handleScroll);
    }
    this.addEventListener('zoom-state-change', this.#handleZoomStateChange);
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    this.refs.dialog.removeEventListener('scroll', this.handleScroll);
    const galleryList = this.querySelector('.dialog-zoomed-gallery');
    if (galleryList) {
      galleryList.removeEventListener('scroll', this.handleScroll);
    }
    this.removeEventListener('zoom-state-change', this.#handleZoomStateChange);
  }

  /**
   * Opens the zoom dialog.
   *
   * @param {number} index - The index of the media to zoom.
   * @param {PointerEvent} event - The pointer event.
   */
  async open(index, event) {
    event.preventDefault();

    const { dialog, media, thumbnails } = this.refs;
    const targetImage = media[index];
    const targetThumbnail = thumbnails.children[index];

    const open = () => {
      dialog.showModal();

      for (const target of [targetThumbnail, targetImage]) {
        target?.scrollIntoView({ behavior: 'instant' });
      }
    };

    /** @type {HTMLElement | null} */
    const sourceImage = event.target instanceof Element ? event.target.closest('li,slideshow-slide') : null;

    if (!supportsViewTransitions() || isLowPowerDevice() || !sourceImage || !targetImage) return open();

    const itemTransitionName = `gallery-item-open`;
    sourceImage.style.setProperty('view-transition-name', itemTransitionName);

    const focalPoint = sourceImage.dataset.focalPoint;
    if (focalPoint) {
      document.documentElement.style.setProperty('--gallery-media-focal-point', focalPoint);
    }

    await startViewTransition(() => {
      open();
      sourceImage.style.removeProperty('view-transition-name');
      targetImage.style.setProperty('view-transition-name', itemTransitionName);
    });

    document.documentElement.style.removeProperty('--gallery-media-focal-point');
    targetImage.style.removeProperty('view-transition-name');

    this.selectThumbnail(index, { behavior: 'instant' });
  }

  /**
   * Loads a high-resolution image for a specific media container
   * @param {HTMLElement} mediaContainer - The media container element
   */
  loadHighResolutionImage(mediaContainer) {
    if (!mediaContainer.classList.contains('product-media-container--image')) return false;

    const image = mediaContainer.querySelector('img.product-media__image');
    if (!image || !(image instanceof HTMLImageElement)) return false;

    const highResolutionUrl = image.getAttribute('data_max_resolution');
    if (!highResolutionUrl || this.#highResImagesLoaded.has(highResolutionUrl)) return false;

    preloadImage(highResolutionUrl);

    const newImage = new Image();
    newImage.className = image.className;
    newImage.alt = image.alt;
    newImage.setAttribute('data_max_resolution', highResolutionUrl);
    newImage.setAttribute('ref', 'image');
    newImage.draggable = false;
    newImage.setAttribute('draggable', 'false');

    // When the high-resolution image loads, replace the existing image
    newImage.onload = () => {
      newImage.draggable = false;
      newImage.setAttribute('draggable', 'false');
      image.replaceWith(newImage);
      this.#highResImagesLoaded.add(highResolutionUrl);
    };

    newImage.src = highResolutionUrl;
  }

  /**
   * Handles the scroll event of the dialog, which is used to update the active thumbnail when the corresponding image is visible in the main view.
   * @param {Event} event - The scroll event.
   */
  handleScroll = debounce(async () => {
    const { media, thumbnails } = this.refs;

    const mostVisibleElement = await getMostVisibleElement(media);
    const activeIndex = media.indexOf(mostVisibleElement);
    const targetThumbnail = thumbnails.children[activeIndex];

    if (!targetThumbnail || !(targetThumbnail instanceof HTMLElement)) return;

    Array.from(thumbnails.querySelectorAll('button')).forEach((button, i) => {
      button.setAttribute('aria-selected', `${i === activeIndex}`);
    });

    const currentIndexEl = this.querySelector('[ref="currentIndex"]');
    if (currentIndexEl) {
      currentIndexEl.textContent = `${activeIndex + 1}`;
    }

    const button = this.querySelector('.dialog-zoomed-gallery__zoom-toggle-button');
    const buttonText = this.querySelector('[ref="zoomButtonText"]');
    if (button) {
      button.setAttribute('data-zoomed', 'false');
      if (buttonText) {
        buttonText.textContent = 'Zoom in';
      }
    }

    this.loadHighResolutionImage(mostVisibleElement);
    this.dispatchEvent(new ZoomMediaSelectedEvent(activeIndex));
  }, 50);

  /**
   * Closes the zoom dialog.
   */
  async close() {
    const { dialog, media } = this.refs;

    if (!supportsViewTransitions() || isLowPowerDevice()) return this.closeDialog();

    // Find the most visible image using IntersectionObserver
    const mostVisibleElement = await getMostVisibleElement(media);

    // Get the index and set up transition
    const activeIndex = media.indexOf(mostVisibleElement);
    const itemTransitionName = `gallery-item-close`;

    const mediaGallery = /** @type {import('./media-gallery').MediaGallery | undefined} */ (
      this.closest('media-gallery')
    );

    const slideshowActive = mediaGallery?.presentation === 'carousel';

    const slide = slideshowActive ? mediaGallery.slideshow?.slides?.[activeIndex] : mediaGallery?.media?.[activeIndex];

    if (!slide) return this.closeDialog();
    const focalPoint = slide.dataset.focalPoint;
    if (focalPoint) {
      document.documentElement.style.setProperty('--gallery-media-focal-point', focalPoint);
    }

    dialog.classList.add('dialog--closed');

    await onAnimationEnd(this.refs.thumbnails);

    mostVisibleElement.style.setProperty('view-transition-name', itemTransitionName);

    await startViewTransition(() => {
      mostVisibleElement.style.removeProperty('view-transition-name');
      slide.style.setProperty('view-transition-name', itemTransitionName);
      this.closeDialog();
    });

    slide.style.removeProperty('view-transition-name');
    dialog.classList.remove('dialog--closed');
    document.documentElement.style.removeProperty('--gallery-media-focal-point');
  }

  async closeDialog() {
    const { dialog } = this.refs;

    // Only play the close animation if not already being handled by the view-transition path
    if (!dialog.classList.contains('dialog--closed')) {
      dialog.classList.add('dialog--closed');
      await new Promise((resolve) => {
        const onEnd = () => { dialog.removeEventListener('animationend', onEnd); resolve(); };
        dialog.addEventListener('animationend', onEnd, { once: true });
        // Safety timeout — if no animation fires (reduced-motion), resolve immediately
        setTimeout(resolve, 300);
      });
      dialog.classList.remove('dialog--closed');
    }

    dialog.close();
    window.dispatchEvent(new DialogCloseEvent());
  }

  /**
   * Closes the dialog when the user presses the escape key.
   *
   * @param {KeyboardEvent} event - The keyboard event.
   */
  handleKeyDown(event) {
    if (event.key !== 'Escape') return;

    event.preventDefault();
    this.close();
  }

  /**
   * Handles the click event of a thumbnail.
   * @param {number} index - The index of the thumbnail to select.
   */
  async handleThumbnailClick(index) {
    const behavior = prefersReducedMotion() ? 'instant' : 'smooth';
    this.selectThumbnail(index, { behavior });
  }

  /**
   * Handles the pointer enter event of a thumbnail.
   * @param {number} index - The index of the thumbnail to load the high-resolution image for.
   */
  async handleThumbnailPointerEnter(index) {
    const { media } = this.refs;
    if (!media[index]) return;

    this.loadHighResolutionImage(media[index]);
  }

  /**
   * Handles the selection of a thumbnail.
   * @param {number} index - The index of the thumbnail to select.
   * @param {Object} options - The options for the selection.
   * @param {ScrollBehavior} options.behavior - The behavior of the scroll.
   */
  async selectThumbnail(index, options = { behavior: 'smooth' }) {
    if (!this.refs.media || !this.refs.media.length) return;

    // Guard if invalid
    if (isNaN(index) || index < 0 || index >= this.refs.media.length) return;

    const { media, thumbnails } = this.refs;
    const targetThumbnail = thumbnails?.children?.[index];

    if (targetThumbnail && targetThumbnail instanceof HTMLElement) {
      Array.from(thumbnails.querySelectorAll('button')).forEach((button, i) => {
        button.setAttribute('aria-selected', `${i === index}`);
      });

      scrollIntoView(targetThumbnail, {
        ancestor: thumbnails,
        behavior: options.behavior,
        block: 'center',
        inline: 'center',
      });
    }

    const targetImage = media[index];

    const currentIndexEl = this.querySelector('[ref="currentIndex"]');
    if (currentIndexEl) {
      currentIndexEl.textContent = `${index + 1}`;
    }

    const button = this.querySelector('.dialog-zoomed-gallery__zoom-toggle-button');
    const buttonText = this.querySelector('[ref="zoomButtonText"]');
    if (button) {
      button.setAttribute('data-zoomed', 'false');
      if (buttonText) {
        buttonText.textContent = 'Zoom in';
      }
    }

    if (targetImage) {
      targetImage.scrollIntoView({
        behavior: options.behavior,
      });

      this.loadHighResolutionImage(targetImage);
    }
    this.dispatchEvent(new ZoomMediaSelectedEvent(index));
  }

  async handlePrevClick() {
    const activeIndex = await this.getActiveIndex();
    if (activeIndex > 0) {
      this.selectThumbnail(activeIndex - 1);
    }
  }

  async handleNextClick() {
    const { media } = this.refs;
    const activeIndex = await this.getActiveIndex();
    if (activeIndex < media.length - 1) {
      this.selectThumbnail(activeIndex + 1);
    }
  }

  async getActiveIndex() {
    const { media } = this.refs;
    const mostVisibleElement = await getMostVisibleElement(media);
    return media.indexOf(mostVisibleElement);
  }

  /**
   * Updates the zoom button label/icon when zoom state changes (e.g. via mouse wheel).
   * @param {CustomEvent} event
   */
  #handleZoomStateChange = (event) => {
    const { isZoomed } = event.detail;
    const button = this.querySelector('.dialog-zoomed-gallery__zoom-toggle-button');
    const buttonText = this.querySelector('[ref="zoomButtonText"]');
    if (button) button.setAttribute('data-zoomed', isZoomed ? 'true' : 'false');
    if (buttonText) buttonText.textContent = isZoomed ? 'Zoom out' : 'Zoom in';
  };

  /**
   * Handles click on a zoomed image — toggles zoom in/out.
   * Previously this was wired to close(), which caused the bug where
   * clicking nav arrows bubbled up to the image container and triggered
   * the close animation, stripping all controls from the UI.
   */
  async handleImageClick() {
    await this.toggleActiveZoom();
  }

  async toggleActiveZoom() {
    const { media } = this.refs;
    const activeIndex = await this.getActiveIndex();
    const activeMedia = media[activeIndex];
    if (activeMedia) {
      const zoomWrapper = activeMedia.querySelector('drag-zoom-wrapper');
      if (zoomWrapper && typeof zoomWrapper.toggleZoom === 'function') {
        // toggleZoom() returns true if now zoomed in, false if zoomed out
        const isZoomed = zoomWrapper.toggleZoom();

        const button = this.querySelector('.dialog-zoomed-gallery__zoom-toggle-button');
        const buttonText = this.querySelector('[ref="zoomButtonText"]');

        if (button) {
          button.setAttribute('data-zoomed', isZoomed ? 'true' : 'false');
        }
        if (buttonText) {
          buttonText.textContent = isZoomed ? 'Zoom out' : 'Zoom in';
        }
      }
    }
  }
}

if (!customElements.get('zoom-dialog')) {
  customElements.define('zoom-dialog', ZoomDialog);
}

/**
 * Get the most visible element from a list of elements.
 * @param {HTMLElement[]} elements - The elements to get the most visible element from.
 * @returns {Promise<HTMLElement>} A promise that resolves to the most visible element.
 */
function getMostVisibleElement(elements) {
  return new Promise((resolve) => {
    const observer = new IntersectionObserver(
      (entries) => {
        const mostVisible = entries.reduce((prev, current) =>
          current.intersectionRatio > prev.intersectionRatio ? current : prev
        );
        observer.disconnect();
        resolve(/** @type {HTMLElement} */ (mostVisible.target));
      },
      {
        threshold: Array.from({ length: 100 }, (_, i) => i / 100),
      }
    );

    for (const element of elements) {
      observer.observe(element);
    }
  });
}
