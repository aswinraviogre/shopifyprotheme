/**
 * Quick-Add Cart Badge
 *
 * Reads per-product quantities from the Shopify Cart API and updates every
 * quick-add button circle with a numeric count badge using CSS data-attributes.
 *
 * + icon → white circle (default, no items in cart)
 * 1, 2 … → black circle (items in cart, CSS handles show/hide via data-has-cart-items)
 */

import { StandardEvents } from '@shopify/events';

/**
 * @returns {Promise<{items: Array<{product_id: number, quantity: number}>} | null>}
 */
async function fetchCart() {
  try {
    const res = await fetch('/cart.js', { credentials: 'same-origin' });
    if (!res.ok) return null;
    return res.json();
  } catch {
    return null;
  }
}

/**
 * Builds a Map of productId (number) → total quantity.
 * @param {Array<{product_id: number, quantity: number}>} items
 * @returns {Map<number, number>}
 */
function buildProductQtyMap(items) {
  const map = new Map();
  for (const item of items) {
    map.set(item.product_id, (map.get(item.product_id) ?? 0) + item.quantity);
  }
  return map;
}

/**
 * Updates all quick-add buttons on the page.
 * Uses data-has-cart-items attribute only — CSS handles the visual toggle.
 * @param {Map<number, number>} qtyMap
 */
function updateBadges(qtyMap) {
  document.querySelectorAll('quick-add-component[data-product-id]').forEach((comp) => {
    const productId = Number(comp.dataset.productId);
    const qty = qtyMap.get(productId) ?? 0;

    comp.querySelectorAll('button.quick-add__button').forEach((btn) => {
      const countBadge = /** @type {HTMLElement | null} */ (btn.querySelector('.quick-add__cart-count'));
      if (!countBadge) return;

      if (qty > 0) {
        const displayCount = qty > 99 ? '99+' : String(qty);

        // Animate only when count changes
        if (countBadge.textContent !== displayCount) {
          countBadge.textContent = displayCount;
          countBadge.classList.remove('quick-add__cart-count--pop');
          void countBadge.offsetWidth; // force reflow to restart animation
          countBadge.classList.add('quick-add__cart-count--pop');
        }

        btn.setAttribute('data-has-cart-items', 'true');
      } else {
        btn.removeAttribute('data-has-cart-items');
        countBadge.textContent = '';
        countBadge.classList.remove('quick-add__cart-count--pop');
      }
    });
  });
}

/**
 * Handles cartLinesUpdate event — resolves promise then refreshes badges.
 * Falls back to /cart.js fetch if event payload lacks item data.
 * @param {import('@shopify/events').CartLinesUpdateEvent} event
 */
async function handleCartUpdate(event) {
  try {
    const result = await event.promise;

    // Theme uses AJAX Cart API: result.detail.items or result.cart.items
    const items =
      result?.detail?.items ??
      result?.cart?.items ??
      // Storefront API shape (edges/nodes)
      result?.cart?.lines?.edges?.map((/** @type {any} */ e) => ({
        product_id: Number(e.node?.merchandise?.product?.id?.split('/').pop()),
        quantity: e.node?.quantity ?? 0,
      }));

    if (Array.isArray(items) && items.length >= 0) {
      updateBadges(buildProductQtyMap(items));
    } else {
      throw new Error('No items in event payload, falling back to /cart.js');
    }
  } catch {
    const cart = await fetchCart();
    if (cart?.items) updateBadges(buildProductQtyMap(cart.items));
  }
}

// Init on page load — populate badges from current cart state
(async () => {
  const cart = await fetchCart();
  if (cart?.items) updateBadges(buildProductQtyMap(cart.items));
})();

// React to all future cart updates
document.addEventListener(StandardEvents.cartLinesUpdate, handleCartUpdate);
