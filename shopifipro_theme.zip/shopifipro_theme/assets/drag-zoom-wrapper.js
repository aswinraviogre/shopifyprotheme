import { DialogCloseEvent } from '@theme/dialog';
import { clamp, preventDefault } from '@theme/utilities';
import { Component } from '@theme/component';

const MIN_ZOOM = 1;
const MAX_ZOOM = 5;
const DEFAULT_ZOOM = 1.5;
const CLICK_ZOOM = 2.5;
const DOUBLE_TAP_DELAY = 300;
const DOUBLE_TAP_DISTANCE = 50;
const DRAG_THRESHOLD = 8;

/**
 * @typedef {object} Refs
 * @property {HTMLImageElement} [image] - The image element to zoom and drag.
 */

/** @extends {Component<Refs>} */
export class DragZoomWrapper extends Component {
  #controller = new AbortController();
  /** @type {number} */
  #scale = MIN_ZOOM;
  /** @type {number} */
  #initialDistance = 0;
  /** @type {number} */
  #startScale = MIN_ZOOM;
  /** @type {Point} */
  #translate = { x: 0, y: 0 };
  /** @type {Point} */
  #startPosition = { x: 0, y: 0 };
  /** @type {Point} */
  #startTranslate = { x: 0, y: 0 };
  /** @type {boolean} */
  #isDragging = false;
  /** @type {boolean} */
  #initialized = false;
  /** @type {number | null} */
  #animationFrame = null;
  /** @type {number} */
  #lastTapTime = 0;
  /** @type {Point | null} */
  #lastTapPosition = null;
  /** @type {boolean} */
  #hasDraggedBeyondThreshold = false;
  /** @type {boolean} */
  #hasManualZoom = false;
  /** @type {{ x: number, y: number, time: number } | null} */
  #pointerDownPos = null;

  get #image() {
    return this.refs?.image || this.querySelector('img.product-media__image') || this.querySelector('img');
  }

  connectedCallback() {
    super.connectedCallback();
    this.#preventImageDrag();
    this.#initResizeListener();
    window.addEventListener(DialogCloseEvent.eventName, this.#resetZoom);
    this.#initEventListeners();
    this.#updateTransform();
  }

  #preventImageDrag() {
    const img = this.#image;
    if (img) {
      img.draggable = false;
      img.setAttribute('draggable', 'false');
    }
  }

  #initResizeListener() {
    this.#resizeObserver.observe(this);
  }

  #initEventListeners() {
    if (this.#initialized) return;
    this.#initialized = true;
    const { signal } = this.#controller;
    const activeOptions = { passive: false, signal };

    // Prevent native browser image drag
    this.addEventListener('dragstart', (e) => e.preventDefault(), { signal });

    // Touch events for pinch-to-zoom on mobile
    this.addEventListener('touchstart', this.#handleTouchStart, activeOptions);
    this.addEventListener('touchmove', this.#handleTouchMove, activeOptions);
    this.addEventListener('touchend', this.#handleTouchEnd, activeOptions);

    // Mouse wheel zoom (desktop)
    this.addEventListener('wheel', this.#handleWheel, activeOptions);

    // Pointer events for desktop mouse / stylus drag-to-pan and click-to-zoom
    this.addEventListener('pointerdown', this.#handlePointerDown, activeOptions);
    this.addEventListener('pointermove', this.#handlePointerMove, activeOptions);
    this.addEventListener('pointerup', this.#handlePointerUp, activeOptions);
    this.addEventListener('pointercancel', this.#handlePointerUp, activeOptions);

    // Initialize transform immediately
    this.#updateTransform();
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    window.removeEventListener(DialogCloseEvent.eventName, this.#resetZoom);
    this.#controller.abort();
    this.#resizeObserver.disconnect();
    this.#cancelAnimationFrame();
  }

  #handleResize = () => {
    if (this.#initialized) {
      this.#requestUpdateTransform();
    }
  };

  #resizeObserver = new ResizeObserver(this.#handleResize);

  // ─── Pointer events (Desktop Mouse & Stylus) ─────────────────────────────

  /**
   * @param {PointerEvent} event
   */
  #handlePointerDown = (event) => {
    // Only handle primary button (left click) or touch/pen
    if (event.pointerType === 'mouse' && event.button !== 0) return;

    this.#preventImageDrag();
    this.#pointerDownPos = { x: event.clientX, y: event.clientY, time: Date.now() };

    if (this.#scale > MIN_ZOOM) {
      this.#isDragging = true;
      this.#hasDraggedBeyondThreshold = false;
      this.#startPosition = { x: event.clientX, y: event.clientY };
      this.#startTranslate = { x: this.#translate.x, y: this.#translate.y };
      this.dataset.mouseDragging = 'true';

      try {
        this.setPointerCapture(event.pointerId);
      } catch (_) {}

      event.preventDefault();
    }
  };

  /**
   * @param {PointerEvent} event
   */
  #handlePointerMove = (event) => {
    if (!this.#isDragging || this.#scale <= MIN_ZOOM) return;

    const dx = event.clientX - this.#startPosition.x;
    const dy = event.clientY - this.#startPosition.y;

    if (!this.#hasDraggedBeyondThreshold) {
      if (Math.hypot(dx, dy) < DRAG_THRESHOLD) return;
      this.#hasDraggedBeyondThreshold = true;
    }

    event.preventDefault();
    this.#translate.x = this.#startTranslate.x + dx / this.#scale;
    this.#translate.y = this.#startTranslate.y + dy / this.#scale;
    this.#requestUpdateTransform();
  };

  /**
   * @param {PointerEvent} event
   */
  #handlePointerUp = (event) => {
    if (this.#isDragging) {
      try {
        this.releasePointerCapture(event.pointerId);
      } catch (_) {}
    }

    const wasDragging = this.#isDragging && this.#hasDraggedBeyondThreshold;
    this.#isDragging = false;
    this.#hasDraggedBeyondThreshold = false;
    delete this.dataset.mouseDragging;

    // Check if this was a click (not a drag)
    if (this.#pointerDownPos && !wasDragging) {
      const dx = Math.abs(event.clientX - this.#pointerDownPos.x);
      const dy = Math.abs(event.clientY - this.#pointerDownPos.y);
      const dt = Date.now() - this.#pointerDownPos.time;

      if (dx < DRAG_THRESHOLD && dy < DRAG_THRESHOLD && dt < 450) {
        if (event.pointerType === 'mouse') {
          this.#zoomAtPoint(event.clientX, event.clientY);
        }
      }
    }

    this.#pointerDownPos = null;
    this.#requestUpdateTransform();
  };

  // ─── Mouse Wheel Zoom (desktop) ──────────────────────────────────────────

  /**
   * Zoom in/out at the cursor position using the mouse wheel.
   * @param {WheelEvent} event
   */
  #handleWheel = (event) => {
    event.preventDefault();

    const rect = this.getBoundingClientRect();
    const cursorX = event.clientX - rect.left;
    const cursorY = event.clientY - rect.top;

    const oldScale = this.#scale;
    const delta = event.deltaMode === 1 ? event.deltaY * 30 : event.deltaY;
    const zoomFactor = 1 - delta * 0.0012;
    const newScale = clamp(oldScale * zoomFactor, MIN_ZOOM, MAX_ZOOM);

    if (newScale === oldScale) return;

    // Adjust translation so the point under the cursor stays fixed
    const containerCenterX = rect.width / 2;
    const containerCenterY = rect.height / 2;
    const distX = cursorX - containerCenterX;
    const distY = cursorY - containerCenterY;
    const scaleDelta = newScale / oldScale - 1.0;

    this.#translate.x -= (distX * scaleDelta) / newScale;
    this.#translate.y -= (distY * scaleDelta) / newScale;
    this.#scale = newScale;
    this.#hasManualZoom = newScale > MIN_ZOOM;

    const isNowZoomed = this.#scale > MIN_ZOOM;
    this.dataset.zoomed = isNowZoomed ? 'true' : 'false';

    this.dispatchEvent(new CustomEvent('zoom-state-change', {
      bubbles: true,
      detail: { isZoomed: isNowZoomed },
    }));

    this.#requestUpdateTransform();
  };

  /**
   * Zooms in or out centered at a specific viewport point (clientX, clientY).
   * @param {number} clientX
   * @param {number} clientY
   * @returns {boolean} isZoomed
   */
  #zoomAtPoint(clientX, clientY) {
    const rect = this.getBoundingClientRect();
    const cursorX = clientX - rect.left;
    const cursorY = clientY - rect.top;

    if (this.#scale > MIN_ZOOM) {
      // Zoom out back to 1x
      this.#scale = MIN_ZOOM;
      this.#translate = { x: 0, y: 0 };
      this.#hasManualZoom = false;
      this.dataset.zoomed = 'false';
    } else {
      // Zoom in to CLICK_ZOOM (2.5x)
      const oldScale = this.#scale;
      this.#scale = CLICK_ZOOM;
      this.#hasManualZoom = true;
      this.dataset.zoomed = 'true';

      const containerCenterX = rect.width / 2;
      const containerCenterY = rect.height / 2;
      const distX = cursorX - containerCenterX;
      const distY = cursorY - containerCenterY;
      const scaleDelta = this.#scale / oldScale - 1.0;

      this.#translate.x -= (distX * scaleDelta) / this.#scale;
      this.#translate.y -= (distY * scaleDelta) / this.#scale;
    }

    const isNowZoomed = this.#scale > MIN_ZOOM;
    this.dispatchEvent(new CustomEvent('zoom-state-change', {
      bubbles: true,
      detail: { isZoomed: isNowZoomed },
    }));

    this.#requestUpdateTransform();
    return isNowZoomed;
  }

  // ─── Touch / Pinch Gestures (mobile) ─────────────────────────────────────

  /**
   * @param {TouchEvent} event
   */
  #handleTouchStart = (event) => {
    const touchCount = event.touches.length;

    if (touchCount === 2) {
      preventDefault(event);
      const touch1 = event.touches[0];
      const touch2 = event.touches[1];
      if (!touch1 || !touch2) return;

      this.#initialDistance = getDistance(touch1, touch2);
      this.#startScale = this.#scale;
      this.#isDragging = false;
    } else if (touchCount === 1) {
      const touch = event.touches[0];
      if (!touch) return;

      const currentTime = performance.now();
      const timeSinceLastTap = currentTime - this.#lastTapTime;

      if (timeSinceLastTap < DOUBLE_TAP_DELAY && this.#lastTapPosition) {
        const distance = getDistance(touch, this.#lastTapPosition);
        if (distance < DOUBLE_TAP_DISTANCE) {
          preventDefault(event);
          this.#handleDoubleTapFromTouch(touch);
          this.#lastTapTime = 0;
          this.#lastTapPosition = null;
          return;
        }
      }

      this.#lastTapTime = currentTime;
      this.#lastTapPosition = { x: touch.clientX, y: touch.clientY };

      if (this.#scale > MIN_ZOOM) {
        preventDefault(event);
        this.#startPosition = { x: touch.clientX, y: touch.clientY };
        this.#startTranslate = { x: this.#translate.x, y: this.#translate.y };
        this.#isDragging = true;
        this.#hasDraggedBeyondThreshold = false;
      }
    }
  };

  /**
   * @param {Touch} touch
   */
  #handleDoubleTapFromTouch(touch) {
    const containerCenter = {
      x: this.clientWidth / 2,
      y: this.clientHeight / 2,
    };

    let targetZoom;
    if (this.#hasManualZoom || this.#scale > MIN_ZOOM + 0.1) {
      targetZoom = MIN_ZOOM;
      this.#hasManualZoom = false;
      this.#translate = { x: 0, y: 0 };
    } else {
      targetZoom = DEFAULT_ZOOM;
    }

    if (targetZoom !== MIN_ZOOM) {
      const oldScale = this.#scale;
      this.#scale = targetZoom;
      const distanceFromCenter = {
        x: touch.clientX - containerCenter.x,
        y: touch.clientY - containerCenter.y,
      };
      const scaleDelta = this.#scale / oldScale - 1.0;
      this.#translate.x -= (distanceFromCenter.x * scaleDelta) / this.#scale;
      this.#translate.y -= (distanceFromCenter.y * scaleDelta) / this.#scale;
      this.dataset.zoomed = 'true';
    } else {
      this.#scale = targetZoom;
      this.#translate = { x: 0, y: 0 };
      this.dataset.zoomed = 'false';
    }

    const isNowZoomed = this.#scale > MIN_ZOOM;
    this.dispatchEvent(new CustomEvent('zoom-state-change', {
      bubbles: true,
      detail: { isZoomed: isNowZoomed },
    }));

    this.#requestUpdateTransform();
  }

  /**
   * @param {TouchEvent} event
   */
  #handleTouchMove = (event) => {
    const touchCount = event.touches.length;

    if (touchCount === 2) {
      preventDefault(event);
      const touch1 = event.touches[0];
      const touch2 = event.touches[1];
      if (!touch1 || !touch2) return;

      const midX = (touch1.clientX + touch2.clientX) / 2;
      const midY = (touch1.clientY + touch2.clientY) / 2;
      const currentDistance = getDistance(touch1, touch2);
      const oldScale = this.#scale;
      const newScale = clamp((currentDistance / this.#initialDistance) * this.#startScale, MIN_ZOOM, MAX_ZOOM);

      this.#scale = newScale;
      this.#hasManualZoom = true;

      const containerCenterX = this.clientWidth / 2;
      const containerCenterY = this.clientHeight / 2;
      const distanceFromCenterX = midX - containerCenterX;
      const distanceFromCenterY = midY - containerCenterY;
      const scaleDelta = this.#scale / oldScale - 1.0;

      this.#translate.x -= (distanceFromCenterX * scaleDelta) / this.#scale;
      this.#translate.y -= (distanceFromCenterY * scaleDelta) / this.#scale;

      this.dataset.zoomed = this.#scale > MIN_ZOOM ? 'true' : 'false';
      this.#requestUpdateTransform();
      this.#isDragging = false;
    } else if (touchCount === 1 && this.#isDragging && this.#scale > MIN_ZOOM) {
      preventDefault(event);
      const touch = event.touches[0];
      if (!touch) return;

      const dx = touch.clientX - this.#startPosition.x;
      const dy = touch.clientY - this.#startPosition.y;

      this.#translate.x = this.#startTranslate.x + dx / this.#scale;
      this.#translate.y = this.#startTranslate.y + dy / this.#scale;
      this.#requestUpdateTransform();
    }
  };

  /**
   * @param {TouchEvent} event
   */
  #handleTouchEnd = (event) => {
    if (event.touches.length === 0) {
      this.#isDragging = false;
      this.#hasDraggedBeyondThreshold = false;
      this.#requestUpdateTransform();
    }
  };

  // ─── Transforms & Constraints ────────────────────────────────────────────

  /**
   * Constrain image translation to keep it comfortably within the viewport
   */
  #constrainTranslation() {
    const containerWidth = this.clientWidth;
    const containerHeight = this.clientHeight;
    if (!containerWidth || !containerHeight) return;

    this.#scale = clamp(this.#scale, MIN_ZOOM, MAX_ZOOM);

    if (this.#scale <= MIN_ZOOM) {
      this.#translate.x = 0;
      this.#translate.y = 0;
      this.style.setProperty('--drag-zoom-scale', '1');
      this.style.setProperty('--drag-zoom-translate-x', '0px');
      this.style.setProperty('--drag-zoom-translate-y', '0px');
      return;
    }

    const wrapperRect = this.getBoundingClientRect();
    const imageElement = this.#image;
    const naturalWidth = imageElement?.naturalWidth || wrapperRect.width;
    const naturalHeight = imageElement?.naturalHeight || wrapperRect.height;

    const imageAspectRatio = naturalWidth / naturalHeight;
    const wrapperAspectRatio = wrapperRect.width / wrapperRect.height;

    let actualImageWidth, actualImageHeight;
    if (imageAspectRatio > wrapperAspectRatio) {
      actualImageWidth = wrapperRect.width;
      actualImageHeight = actualImageWidth / imageAspectRatio;
    } else {
      actualImageHeight = wrapperRect.height;
      actualImageWidth = actualImageHeight * imageAspectRatio;
    }

    const scaledImageWidth = actualImageWidth * this.#scale;
    const scaledImageHeight = actualImageHeight * this.#scale;

    const maxTranslateX = Math.max(
      (scaledImageWidth - wrapperRect.width) / 2 + 100,
      scaledImageWidth * 0.45
    ) / this.#scale;

    const maxTranslateY = Math.max(
      (scaledImageHeight - wrapperRect.height) / 2 + 100,
      scaledImageHeight * 0.45
    ) / this.#scale;

    this.#translate.x = clamp(this.#translate.x, -maxTranslateX, maxTranslateX);
    this.#translate.y = clamp(this.#translate.y, -maxTranslateY, maxTranslateY);

    this.style.setProperty('--drag-zoom-scale', this.#scale.toString());
    this.style.setProperty('--drag-zoom-translate-x', `${this.#translate.x}px`);
    this.style.setProperty('--drag-zoom-translate-y', `${this.#translate.y}px`);

    if (imageElement) {
      imageElement.style.transform = `scale(${this.#scale}) translate(${this.#translate.x}px, ${this.#translate.y}px)`;
      imageElement.style.transformOrigin = 'center center';
    }
  }

  #requestUpdateTransform = () => {
    if (!this.#animationFrame) {
      this.#animationFrame = requestAnimationFrame(this.#updateTransform);
    }
  };

  #cancelAnimationFrame() {
    if (this.#animationFrame) {
      cancelAnimationFrame(this.#animationFrame);
      this.#animationFrame = null;
    }
  }

  #updateTransform = () => {
    this.#animationFrame = null;
    this.#constrainTranslation();
  };

  /**
   * Reset zoom to 1x (called when dialog closes)
   */
  #resetZoom = () => {
    this.#scale = MIN_ZOOM;
    this.#startScale = MIN_ZOOM;
    this.#translate.x = 0;
    this.#translate.y = 0;

    this.#startPosition = { x: 0, y: 0 };
    this.#startTranslate = { x: 0, y: 0 };
    this.#isDragging = false;
    this.#lastTapTime = 0;
    this.#lastTapPosition = null;
    this.#hasDraggedBeyondThreshold = false;
    this.#hasManualZoom = false;
    this.#pointerDownPos = null;

    delete this.dataset.zoomed;
    delete this.dataset.mouseDragging;

    this.style.setProperty('--drag-zoom-scale', MIN_ZOOM.toString());
    this.style.setProperty('--drag-zoom-translate-x', '0px');
    this.style.setProperty('--drag-zoom-translate-y', '0px');

    const img = this.#image;
    if (img) {
      img.style.transform = '';
      img.style.transformOrigin = '';
    }
  };

  toggleZoom() {
    const rect = this.getBoundingClientRect();
    return this.#zoomAtPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
  }

  destroy() {
    this.#controller.abort();
    this.#cancelAnimationFrame();
  }
}

/**
 * @param {Point | Touch} point1
 * @param {Point | Touch} point2
 * @returns {number}
 */
function getDistance(point1, point2) {
  const x1 = /** @type {Point} */ (point1).x ?? /** @type {Touch} */ (point1).clientX;
  const y1 = /** @type {Point} */ (point1).y ?? /** @type {Touch} */ (point1).clientY;
  const x2 = /** @type {Point} */ (point2).x ?? /** @type {Touch} */ (point2).clientX;
  const y2 = /** @type {Point} */ (point2).y ?? /** @type {Touch} */ (point2).clientY;
  const dx = x1 - x2;
  const dy = y1 - y2;
  return Math.sqrt(dx * dx + dy * dy);
}

if (!customElements.get('drag-zoom-wrapper')) {
  customElements.define('drag-zoom-wrapper', DragZoomWrapper);
}

/**
 * @typedef {Object} Point
 * @property {number} x
 * @property {number} y
 */
