/**
 * Universal Scroll Intro Reveal Animation for All Sections
 * High-performance IntersectionObserver revealing sections as they scroll into view.
 */
(function initScrollReveal() {
  if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.querySelectorAll('.shopify-section, section, .section, .custom-size-chart-section').forEach(sec => {
      sec.classList.add('scroll-reveal-visible');
    });
    return;
  }

  const observerOptions = {
    root: null,
    rootMargin: '0px 0px -40px 0px',
    threshold: 0.04
  };

  const revealObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('scroll-reveal-visible');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  function observeSections() {
    const selector = '.shopify-section, section, .section, .custom-size-chart-section';
    const targets = document.querySelectorAll(selector);

    targets.forEach((el, index) => {
      const rect = el.getBoundingClientRect();
      // If section is near or above the initial viewport, reveal immediately without lag
      if (rect.top < window.innerHeight * 0.9 || index === 0) {
        el.classList.add('scroll-reveal-visible');
      } else {
        revealObserver.observe(el);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', observeSections);
  } else {
    observeSections();
  }

  // Support Shopify Theme Editor live section loads & page transitions
  document.addEventListener('shopify:section:load', observeSections);
  document.addEventListener('page:loaded', observeSections);
})();
