/**
 * Bhoomika Luxury Theme - Wishlist Manager
 * Features:
 * - Persistent localStorage management
 * - Real-time sync between product card buttons, header count badge, and slide-over drawer
 * - Lucide heart animation states
 * - Direct Add-to-Cart from wishlist drawer
 */

(function () {
  const STORAGE_KEY = 'bhoomi_wishlist';

  class BhoomiWishlist {
    constructor() {
      this.init();
    }

    init() {
      this.bindEvents();
      this.syncUI();

      // Observe dynamic DOM changes (e.g. pagination, infinite scroll, collection filter updates)
      if (window.MutationObserver) {
        const observer = new MutationObserver(() => {
          this.syncCardButtons();
        });
        observer.observe(document.body, { childList: true, subtree: true });
      }
    }

    getWishlist() {
      try {
        const items = localStorage.getItem(STORAGE_KEY);
        return items ? JSON.parse(items) : [];
      } catch (e) {
        console.error('Error reading wishlist from localStorage', e);
        return [];
      }
    }

    saveWishlist(list) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
      } catch (e) {
        console.error('Error saving wishlist to localStorage', e);
      }
    }

    isInWishlist(productId) {
      const list = this.getWishlist();
      return list.some((item) => String(item.id) === String(productId));
    }

    toggleProduct(productData, triggerBtn = null) {
      let list = this.getWishlist();
      const existingIndex = list.findIndex((item) => String(item.id) === String(productData.id));
      let added = false;

      if (existingIndex > -1) {
        // Remove
        list.splice(existingIndex, 1);
        added = false;
      } else {
        // Add
        list.unshift(productData);
        added = true;
      }

      this.saveWishlist(list);

      // Play pop animation on the clicked button if added
      if (triggerBtn && added) {
        triggerBtn.classList.remove('just-toggled');
        void triggerBtn.offsetWidth; // Trigger reflow
        triggerBtn.classList.add('just-toggled');
      }

      this.dispatchUpdate(list, added, productData);
      this.syncUI();
    }

    removeProduct(productId) {
      let list = this.getWishlist();
      list = list.filter((item) => String(item.id) !== String(productId));
      this.saveWishlist(list);
      this.dispatchUpdate(list, false, { id: productId });
      this.syncUI();
    }

    clearWishlist() {
      this.saveWishlist([]);
      this.dispatchUpdate([], false, null);
      this.syncUI();
    }

    dispatchUpdate(list, wasAdded, product) {
      window.dispatchEvent(
        new CustomEvent('wishlist:updated', {
          detail: {
            wishlist: list,
            count: list.length,
            wasAdded,
            product,
          },
        })
      );
    }

    syncUI() {
      const list = this.getWishlist();
      this.syncCardButtons(list);
      this.syncHeaderBadge(list.length);
      this.renderDrawer(list);
    }

    syncCardButtons(list = this.getWishlist()) {
      const buttons = document.querySelectorAll('[data-wishlist-button]');
      buttons.forEach((btn) => {
        const prodId = btn.getAttribute('data-product-id');
        const active = list.some((item) => String(item.id) === String(prodId));
        if (active) {
          btn.classList.add('is-active');
          btn.setAttribute('aria-label', `Remove ${btn.getAttribute('data-product-title') || ''} from wishlist`);
          btn.setAttribute('title', 'Remove from Wishlist');
        } else {
          btn.classList.remove('is-active');
          btn.setAttribute('aria-label', `Add ${btn.getAttribute('data-product-title') || ''} to wishlist`);
          btn.setAttribute('title', 'Save to Wishlist');
        }
      });
    }

    syncHeaderBadge(count) {
      const badges = document.querySelectorAll('[data-wishlist-count-badge]');
      badges.forEach((badge) => {
        badge.textContent = count;
        if (count > 0) {
          badge.classList.add('has-items');
          badge.style.display = 'inline-flex';
        } else {
          badge.classList.remove('has-items');
          badge.style.display = 'none';
        }
      });

      const drawerCounts = document.querySelectorAll('[data-wishlist-drawer-count]');
      drawerCounts.forEach((el) => {
        el.textContent = count;
      });
    }

    openDrawer() {
      const root = document.getElementById('wishlist-drawer-root');
      if (root) {
        root.classList.add('is-open');
        root.setAttribute('aria-hidden', 'false');
        document.body.classList.add('wishlist-drawer-open');
        document.body.style.overflow = 'hidden';
      }
    }

    closeDrawer() {
      const root = document.getElementById('wishlist-drawer-root');
      if (root) {
        root.classList.remove('is-open');
        root.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('wishlist-drawer-open');
        document.body.style.overflow = '';
      }
    }

    renderDrawer(list = this.getWishlist()) {
      const container = document.querySelector('[data-wishlist-items-container]');
      const emptyState = document.querySelector('[data-wishlist-empty-state]');
      const footer = document.querySelector('[data-wishlist-footer]');

      if (!container) return;

      if (!list || list.length === 0) {
        if (emptyState) emptyState.style.display = 'flex';
        if (footer) footer.style.display = 'none';
        container.innerHTML = '';
        return;
      }

      if (emptyState) emptyState.style.display = 'none';
      if (footer) footer.style.display = 'flex';

      const html = list
        .map((item) => {
          const isAvailable = item.available !== false && item.available !== 'false';
          const comparePriceHtml = item.comparePrice
            ? `<span class="wishlist-item-card__compare-price">${item.comparePrice}</span>`
            : '';

          return `
            <div class="wishlist-item-card" data-wishlist-item-id="${item.id}">
              <a href="${item.url || '#'}" class="wishlist-item-card__image-link" aria-label="${item.title}">
                <img 
                  src="${item.image || 'https://via.placeholder.com/150'}" 
                  alt="${item.title}" 
                  class="wishlist-item-card__image" 
                  loading="lazy"
                />
              </a>
              <div class="wishlist-item-card__content">
                <div>
                  <div class="wishlist-item-card__title-row">
                    <a href="${item.url || '#'}" class="wishlist-item-card__title">
                      ${item.title}
                    </a>
                    <button 
                      type="button" 
                      class="wishlist-item-card__remove-btn" 
                      data-wishlist-drawer-remove="${item.id}"
                      aria-label="Remove ${item.title} from wishlist"
                      title="Remove"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="18" y1="6" x2="6" y2="18"></line>
                        <line x1="6" y1="6" x2="18" y2="18"></line>
                      </svg>
                    </button>
                  </div>
                  <div class="wishlist-item-card__price-row">
                    <span class="wishlist-item-card__price">${item.price || ''}</span>
                    ${comparePriceHtml}
                  </div>
                </div>
                <div class="wishlist-item-card__actions">
                  <button 
                    type="button" 
                    class="wishlist-item-card__add-btn" 
                    data-wishlist-add-to-cart="${item.variantId || ''}"
                    ${!isAvailable ? 'disabled' : ''}
                  >
                    ${isAvailable ? 'Add to Cart' : 'Sold Out'}
                  </button>
                </div>
              </div>
            </div>
          `;
        })
        .join('');

      container.innerHTML = html;
    }

    async handleAddToCart(variantId, buttonEl) {
      if (!variantId || !buttonEl) return;

      const originalText = buttonEl.textContent;
      buttonEl.disabled = true;
      buttonEl.classList.add('is-adding');
      buttonEl.textContent = 'Adding...';

      try {
        const response = await fetch('/cart/add.js', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
          body: JSON.stringify({
            items: [
              {
                id: Number(variantId),
                quantity: 1,
              },
            ],
          }),
        });

        if (response.ok) {
          buttonEl.classList.remove('is-adding');
          buttonEl.classList.add('is-success');
          buttonEl.textContent = 'Added ✓';

          // Trigger cart updates
          document.dispatchEvent(new CustomEvent('cart:updated'));
          window.dispatchEvent(new CustomEvent('cart:updated'));

          // Try to open cart drawer if available
          const cartTrigger = document.querySelector('[data-testid="cart-drawer-trigger"]');
          setTimeout(() => {
            buttonEl.classList.remove('is-success');
            buttonEl.disabled = false;
            buttonEl.textContent = originalText;
            if (cartTrigger) {
              this.closeDrawer();
              cartTrigger.click();
            }
          }, 800);
        } else {
          throw new Error('Failed to add to cart');
        }
      } catch (err) {
        console.error('Error adding wishlist item to cart:', err);
        buttonEl.classList.remove('is-adding');
        buttonEl.disabled = false;
        buttonEl.textContent = 'Failed - Try again';
        setTimeout(() => {
          buttonEl.textContent = originalText;
        }, 2000);
      }
    }

    bindEvents() {
      // 1. Delegated click on Product Card Wishlist Heart Button
      document.addEventListener('click', (e) => {
        const btn = e.target.closest('[data-wishlist-button]');
        if (btn) {
          e.preventDefault();
          e.stopPropagation();

          const productData = {
            id: btn.getAttribute('data-product-id'),
            handle: btn.getAttribute('data-product-handle'),
            title: btn.getAttribute('data-product-title'),
            price: btn.getAttribute('data-product-price'),
            rawPrice: btn.getAttribute('data-product-price-raw'),
            comparePrice: btn.getAttribute('data-product-compare-price'),
            image: btn.getAttribute('data-product-image'),
            url: btn.getAttribute('data-product-url'),
            variantId: btn.getAttribute('data-variant-id'),
            available: btn.getAttribute('data-available'),
          };

          this.toggleProduct(productData, btn);
        }
      });

      // 2. Open Wishlist Drawer from Header Action or any custom trigger
      document.addEventListener('click', (e) => {
        const trigger = e.target.closest('[data-wishlist-header-btn], [data-open-wishlist-drawer]');
        if (trigger) {
          e.preventDefault();
          e.stopPropagation();
          this.openDrawer();
        }
      });

      // 3. Close Wishlist Drawer
      document.addEventListener('click', (e) => {
        const closeBtn = e.target.closest('[data-wishlist-close]');
        if (closeBtn) {
          this.closeDrawer();
        }
      });

      // 4. Remove item from Wishlist Drawer
      document.addEventListener('click', (e) => {
        const removeBtn = e.target.closest('[data-wishlist-drawer-remove]');
        if (removeBtn) {
          e.preventDefault();
          e.stopPropagation();
          const prodId = removeBtn.getAttribute('data-wishlist-drawer-remove');
          this.removeProduct(prodId);
        }
      });

      // 5. Add to Cart from Wishlist Drawer
      document.addEventListener('click', (e) => {
        const addBtn = e.target.closest('[data-wishlist-add-to-cart]');
        if (addBtn && !addBtn.disabled) {
          e.preventDefault();
          e.stopPropagation();
          const variantId = addBtn.getAttribute('data-wishlist-add-to-cart');
          this.handleAddToCart(variantId, addBtn);
        }
      });

      // 6. Clear All Wishlist
      document.addEventListener('click', (e) => {
        const clearBtn = e.target.closest('[data-wishlist-clear]');
        if (clearBtn) {
          e.preventDefault();
          if (confirm('Are you sure you want to remove all items from your wishlist?')) {
            this.clearWishlist();
          }
        }
      });

      // 7. Close drawer on Escape key
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' || e.key === 'Esc') {
          this.closeDrawer();
        }
      });

      // 8. Listen for custom sync events (e.g. if updated from another tab or script)
      window.addEventListener('storage', (e) => {
        if (e.key === STORAGE_KEY) {
          this.syncUI();
        }
      });
    }
  }

  // Initialize and expose to window for global access
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      window.BhoomiWishlist = new BhoomiWishlist();
    });
  } else {
    window.BhoomiWishlist = new BhoomiWishlist();
  }
})();
